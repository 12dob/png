module.exports = {
    readFile: function(filename, options, callback) {
        throw new Error("Not implemented: readFile");
    },
    writeFile: function(filename, data, callback) {
        throw new Error("Not implemented: writeFile");
    }
};
