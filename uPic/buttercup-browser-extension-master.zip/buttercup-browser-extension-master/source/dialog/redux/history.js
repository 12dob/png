import { createHashHistory } from "history";

export default createHashHistory();
