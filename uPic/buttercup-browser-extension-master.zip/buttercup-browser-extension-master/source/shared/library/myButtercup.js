export const MYBUTTERCUP_CLIENT_ID = "bcup_browser_ext";
export const MYBUTTERCUP_CLIENT_SECRET = "71cf1f22921b5ceb84d7ea71d95a854b";
export const MYBUTTERCUP_REDIRECT_URI = "https://my.buttercup.pw/oauth/authorized/";
// export const MYBUTTERCUP_REDIRECT_URI = "http://localhost:8000/oauth/authorized/";
