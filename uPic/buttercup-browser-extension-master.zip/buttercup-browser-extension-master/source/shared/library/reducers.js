export function emptyReducer(state = {}) {
    return state;
}
