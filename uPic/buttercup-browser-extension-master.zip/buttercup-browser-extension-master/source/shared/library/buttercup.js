const { init } = (module.exports = require("buttercup/web"));

init();
