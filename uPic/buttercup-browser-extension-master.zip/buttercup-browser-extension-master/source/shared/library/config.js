export const INITIAL_CONFIG = {
    darkMode: false,
    dynamicIcons: "enabled",
    showSaveDialog: "always", // always/unlocked/never
    autoUnlockVaults: true,
    autoLockVaults: "off"
};
