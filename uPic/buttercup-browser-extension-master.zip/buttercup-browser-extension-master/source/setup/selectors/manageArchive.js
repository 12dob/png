const KEY = "manageArchive";

export function isEditing(state) {
    return state[KEY].editing;
}
