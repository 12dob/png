import { createAction } from "redux-actions";
import { MANAGE_ARCHIVE_SET_EDITING } from "./types.js";

export const setEditing = createAction(MANAGE_ARCHIVE_SET_EDITING);
